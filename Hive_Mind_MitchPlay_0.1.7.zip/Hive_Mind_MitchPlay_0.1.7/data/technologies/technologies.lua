local require = function(name) return require("data/technologies/"..name) end

require("biter_damage")