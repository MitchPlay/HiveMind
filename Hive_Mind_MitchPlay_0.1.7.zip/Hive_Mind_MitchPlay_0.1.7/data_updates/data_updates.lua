names = require("shared")
require("data_updates/adjust_biters")
require("data_updates/balance_flamethrower")
--require("data_updates/attack_proxies")