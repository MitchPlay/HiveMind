## Hive Mind MitchPlay

--------------------------------------

Take control of the Biters, defend your home planet from the foreign invaders, The Engineers. Build Spawners and influence a pollution based economy, and lead yourself to Victory!