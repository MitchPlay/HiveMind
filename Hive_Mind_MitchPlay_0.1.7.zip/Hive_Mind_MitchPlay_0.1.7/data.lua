names = require("shared")

require("data/entities/entities")
require("data/technologies/technologies")
require("data/tiles/creep")